import type { RemoveBgImageOptions } from './types';
type ImglyRemoveBackground = (image: string | Blob | ArrayBuffer, config?: {
    publicPath?: string;
    progress?: (key: string, current: number, total: number) => void;
    debug?: boolean;
}) => Promise<Blob>;
declare global {
    interface Window {
        imglyRemoveBackground?: ImglyRemoveBackground;
    }
}
export declare const BackgroundRemover: {
    /**
     * Checks if the background removal library is loaded.
     */
    isAvailable(): boolean;
    /**
     * Removes background from an image.
     * Returns a Blob of the processed image (PNG).
     *
     * Requires @imgly/background-removal to be loaded via CDN script tag.
     */
    remove(uri: string, options: RemoveBgImageOptions): Promise<Blob>;
};
export {};
